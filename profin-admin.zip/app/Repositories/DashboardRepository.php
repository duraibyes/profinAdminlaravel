<?php
namespace App\Repositories;

use App\Models\Master\Customer;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Models\Payment;
use App\Models\Product\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DashboardRepository
{

}